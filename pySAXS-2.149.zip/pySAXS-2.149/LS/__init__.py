'''
Lions SAXS package
contains all the necessary for SAXS treatment
and SAXS modelization
'''